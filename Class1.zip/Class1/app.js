var bangla = prompt("bangla exam no");
var english = prompt("english exam no");
var match = prompt("match exam no");
var ict = prompt("ict exam no");
var accounting = prompt("accounting exam no");
var physics = prompt("physics exam no");

console.log("your bangla exam number " + bangla + " out of 100");
console.log("your english exam number " + english + " out of 100");
console.log("your match exam number " + match + " out of 100");
console.log("your ICT exam number " + ict + " out of 100");
console.log("your Accounting exam number " + accounting + " out of 100");
console.log("your physics exam number " + physics + " out of 100");

var name = prompt("What is your Name");
var skill = prompt("What is you skill");

document.querySelector("h1").innerHTML =
  "My name is " + name + " I am a " + skill;

console.log(confirm("apni ki shadi korte raji acen?"));
console.dir("Hello World. I love javascript");
