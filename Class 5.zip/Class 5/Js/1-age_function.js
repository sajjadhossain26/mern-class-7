

let name = (prompt('Your name here'));
let age = Number(prompt('Your Age here'));

function Pepolelist(){

    this.pepolever = function (name, age){
        
        if(age >= 0 && age <= 5){
            return `${name} Tumi এখনো বাচ্চা আছ Tumar বয়স ${age} বছর।`
        }
    
        else if(age >= 6 && age <= 17){
            return `${name} Tumi এখনো teenagers Tumar বয়স ${age} বছর`
        }
        else if(age >= 18 && age <= 40 ){
            return `${name} আপনি এখন young এখনই তো আপনার জীবন নিজের মত করে কাটানোর সময় আপার বয়স ${age} বছর`
        }
        else if(age >= 40 && age < 100 ){
            return `${name} আপনি এখন বৃদ্ধ এখনই তো আপনার জীবনের সব ভুল গুলো সমাধান করার সময়। আপার বয়স ${age} বছর`
        }
        else{
            return `${name} আপনি কি ভুত নাকি তো বয়স কোন মানুষের হয় না সহজে ${age} বছর`
        }
    }
}

let people = new Pepolelist();

console.log(people.pepolever(name, age));
