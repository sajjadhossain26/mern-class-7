let agecal = (age) => {
  return `Now your age is ${2021 - age}`;
};
let age = Number(prompt("Please enter date of birth"));
console.log(agecal(age));
