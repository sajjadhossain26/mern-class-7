for (let i = 1000; i >= 300; i--) {
  console.log(i + " I love js");
}
