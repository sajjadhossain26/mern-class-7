for (let i = 1; i < 500; i++) {
  if (i % 3 == 0) {
    console.log("it's divisible by 3 : " + i);
  } else if (i % 4 == 0) {
    console.log("it's divisible by 4 : " + i);
  }
}
