for (let i = 1; i < 10000; i += 3) {
  console.log(i);
  if (i % 11 == 0) {
    break;
  }
}
