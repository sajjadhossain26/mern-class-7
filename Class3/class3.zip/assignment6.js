for (let i = 10000; i <= 10050; i++) {
  console.log(i + " We love js");
}
for (let i = 1050; i >= 1000; i--) {
  console.log(i + " we love js");
}
