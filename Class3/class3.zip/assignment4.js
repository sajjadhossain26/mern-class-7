for (let i = 1; i < 1000; i++) {
  if (i % 3 == 0) {
    console.log(i + " I love js");
  }
}
