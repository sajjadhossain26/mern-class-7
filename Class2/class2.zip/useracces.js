let age = prompt("Please enter your age");

if (age < 20) {
  console.log(`Apni ekono bacca acen ${20 - age} bocor pore asien`);
} else if (age >= 20 && age <= 35) {
  console.log(`apnakei to ami koctecilam asen taratari`);
} else {
  console.log(`apni bora hoie gecen dado`);
}
